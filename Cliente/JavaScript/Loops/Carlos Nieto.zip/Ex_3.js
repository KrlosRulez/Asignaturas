window.onload = function () {

    for (var i = 0; i <= 10; i++) {
        console.log(`${i} * 9 = ${i*9}`);
    }

}