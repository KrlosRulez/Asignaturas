window.onload = function () {

    var fruit_name = prompt("Enter a name of a fruit");

    if (fruit_name == "Banana") {
        alert("I like bananas");
    } else if (fruit_name == "Apple") {
        alert("I like apples");
    } else {
        alert("I don't like fruits");
    }

}