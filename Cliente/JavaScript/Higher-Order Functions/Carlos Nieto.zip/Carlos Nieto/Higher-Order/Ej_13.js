window.onload = function () {

    // find: returns the first matching element based on the condition
    // findIndex: returns the index of the first matching element based on the condition

}