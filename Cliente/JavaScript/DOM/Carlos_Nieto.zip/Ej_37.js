window.onload = function () {

    // ############################################################

    var section_container = document.getElementById("container");

    var new_parraf = document.createElement("p");

    new_parraf.innerText = "Viva el";

    section_container.appendChild(new_parraf);

    // ############################################################

    section_container = document.querySelector("section#container");

    var new_parrafaf = document.createElement("p");

    new_parrafaf.innerText = "Betis";

    section_container.appendChild(new_parrafaf);

    // ############################################################

    var class_second = document.querySelectorAll(".second");

    for (let value of class_second) {

        value.innerHTML = "<b>" + value.innerText + "</b>"

    }

    // ############################################################

    var class_third = document.querySelectorAll(".third");

    for (let value of class_third) {

        value.style.fontStyle = "italic";

    }

    // ############################################################

    var div_footer = document.getElementsByClassName("footer")[0];
    
    div_footer.classList.add("main");

    // ############################################################

    div_footer.classList.remove("footer");

    // ############################################################

    var four_li = document.createElement("li");

    four_li.innerText = "four";

    // ############################################################

    var the_ul = document.getElementsByTagName("ul")[0];

    the_ul.appendChild(four_li);

    // ############################################################

    var all_li = document.querySelectorAll("ol li");

    for (let value of all_li) {

        value.style.backgroundColor = "green";

    }

    // ############################################################

    var div_main = document.querySelector("div.main");

    div_main.remove();

}