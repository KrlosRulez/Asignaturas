<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AREA PRIVADA</title>
</head>

<?php require("../check_session.php"); ?>

<body>

    <?php include("menu.php"); ?>

    <br>
    <h1>GESTIÓN DE LOS DATOS DE LA WEB</h1>

</body>

</html>