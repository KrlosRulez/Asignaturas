<h2>
    <a href="Libros.php">Libros</a>&nbsp;&nbsp;
    <a href="Categorias.php">Categorías</a>&nbsp;&nbsp;
    <a href="Autores.php">Autores</a>&nbsp;&nbsp;
</h2>