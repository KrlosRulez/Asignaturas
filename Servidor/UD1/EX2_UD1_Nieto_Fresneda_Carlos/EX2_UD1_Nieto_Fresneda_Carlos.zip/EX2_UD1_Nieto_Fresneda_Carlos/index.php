<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>

    <h1>Carlos Nieto Fresneda</h1>

    <a href="Ej_1.php">Ejercicio 1</a><br />
    <a href="Ej_2.php">Ejercicio 2</a><br />
    <a href="Ej_3.php">Ejercicio 3</a><br />
    <a href="Ej_4.php">Ejercicio 4</a><br />

</body>
</html>